<template>
  <MDBContainer>
    <div
      class="d-flex justify-content-center align-items-center"
      style="height: 100vh"
    >
      <div class="text-center">
        <img
          class="mb-4"
          src="https://mdbootstrap.com/img/logo/mdb-transparent-250px.png"
          style="width: 250px; height: 90px"
        />
        <h5 class="mb-3">
          Thank you for using our product. We're glad you're with us.
        </h5>
        <p class="mb-3">MDB Team</p>
        <a
          class="btn btn-primary btn-lg"
          href="https://mdbootstrap.com/docs/standard/getting-started/"
          target="_blank"
          role="button"
          >Start MDB tutorial</a
        >
        <p class="mt-4">
          <a href="https://mdbootstrap.com/sale/free/"
            ><i class="far fa-lg fa-surprise"></i> Free users buy cheaper ..
          </a>
        </p>
      </div>
    </div>
  </MDBContainer>
</template>

<script>
import { MDBContainer } from "mdb-vue-ui-kit";

export default {
  name: "HelloWorld",
  components: {
    MDBContainer,
  },
  props: {
    msg: String,
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped></style>
